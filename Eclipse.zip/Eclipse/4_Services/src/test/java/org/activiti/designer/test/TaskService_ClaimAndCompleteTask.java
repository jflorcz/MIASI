package org.activiti.designer.test;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.Map;
import java.io.FileInputStream;

import org.activiti.engine.IdentityService;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.identity.User;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.activiti.engine.test.ActivitiRule;
import org.activiti.engine.test.Deployment;
import org.junit.Rule;
import org.junit.Test;

public class TaskService_ClaimAndCompleteTask {

	@Rule
	public ActivitiRule activitiRule = new ActivitiRule();

	@Test
	public void createTask() {
		TaskService taskService = activitiRule.getTaskService();
		Task task = taskService.newTask();
		task.setName("Test task");
		task.setPriority(100);
		taskService.saveTask(task);
		assertNull(task.getAssignee());
		IdentityService identityService =
				activitiRule.getIdentityService();
		User user = identityService.newUser("JohnDoe");
		identityService.saveUser(user);
		taskService.addCandidateUser(task.getId(), "JohnDoe");
		task = taskService.createTaskQuery()
				.taskCandidateUser("JohnDoe")
				.singleResult();
		assertNotNull(task);
		assertEquals("Test task", task.getName());
		assertNull(task.getAssignee());
		taskService.claim(task.getId(), "JohnDoe");
		task = taskService.createTaskQuery()
				.taskAssignee("JohnDoe")
				.singleResult();
		assertEquals("JohnDoe", task.getAssignee());
		taskService.complete(task.getId());
		task = taskService.createTaskQuery()
				.taskAssignee("JohnDoe")
				.singleResult();
		assertNull(task);
	}
}