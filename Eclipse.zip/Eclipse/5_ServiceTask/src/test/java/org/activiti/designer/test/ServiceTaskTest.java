package org.activiti.designer.test;

import static org.junit.Assert.*;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.io.FileInputStream;

import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.test.ActivitiRule;
import org.activiti.engine.test.Deployment;
import org.junit.Rule;
import org.junit.Test;

public class ServiceTaskTest {

	@Rule
	public ActivitiRule activitiRule = new ActivitiRule();

	private ProcessInstance startProcessInstance() {
		RuntimeService runtimeService = activitiRule.getRuntimeService();
		Map<String, Object> variableMap =
				new HashMap<String, Object>();
		variableMap.put("isbn", 123456L);
		return runtimeService.startProcessInstanceByKey(
				"bookorder", variableMap);
	}

	@Test
	@Deployment(resources={"diagrams/bookorder.bpmn"})
	public void executeJavaService() {
		ProcessInstance processInstance = startProcessInstance();
		RuntimeService runtimeService =
				activitiRule.getRuntimeService();
		Date validatetime = (Date) runtimeService.getVariable(
				processInstance.getId(), "validatetime");
		assertNotNull(validatetime);
		System.out.println("validatetime is " + validatetime);
	}
}