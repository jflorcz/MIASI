package ProcessWithBoundaryEvent;
import java.util.Collection;
import java.util.Map;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;

public class PrzygotujWniosek implements JavaDelegate {
	public void execute(DelegateExecution execution) {
		System.out.println("Przygotowanie wniosku");
		
		
		Map<String, Object> variables = execution.getVariables();
		LoanApplication la = new LoanApplication();
		
		la.setCustomerName((String)
				execution.getVariable("name"));
		
		la.setCreditCheckOk((Boolean) 
				execution.getVariable("creditCheckOk"));
		
		la.setIncome((Long) execution.getVariable("income"));
		la.setRequestedAmount((Long)
				execution.getVariable("loanAmount"));
		la.setEmailAddress((String)
				execution.getVariable("emailAddress"));
		execution.setVariable("loanApplication", la);
		
		System.out.println(la.toString());
	}
}