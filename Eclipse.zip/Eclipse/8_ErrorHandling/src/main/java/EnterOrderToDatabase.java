import org.activiti.engine.impl.pvm.PvmTransition;
import org.activiti.engine.impl.pvm.delegate.ActivityBehavior;
import org.activiti.engine.impl.pvm.delegate.ActivityExecution;


public class EnterOrderToDatabase implements ActivityBehavior {

	@Override
	public void execute(ActivityExecution execution) throws Exception {
		int age = (Integer) execution.getVariable("age");
		PvmTransition transition;
		
		if (age > 20){
			transition = execution.getActivity().findOutgoingTransition("orderNotPersisted");
		} else {
			transition = execution.getActivity().findOutgoingTransition("orderPersisted");
		}
		
		execution.take(transition);	
	}

}
