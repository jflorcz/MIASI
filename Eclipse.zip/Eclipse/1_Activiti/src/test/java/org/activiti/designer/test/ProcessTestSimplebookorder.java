package org.activiti.designer.test;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.Map;
import java.io.File;
import java.io.FileInputStream;

import org.activiti.engine.ProcessEngine;
import org.activiti.engine.ProcessEngineConfiguration;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.runtime.ProcessInstance;
import org.junit.Test;

public class ProcessTestSimplebookorder {

	private String filename = "./src/main/resources/diagrams/MyProcess.bpmn";

	@Test
	public void startProcess() throws Exception {

		File fi = new File(filename);
		String absolutePath = fi.getAbsolutePath();

		ProcessEngine processEngine = ProcessEngineConfiguration
				.createStandaloneInMemProcessEngineConfiguration()
				.buildProcessEngine();
		RuntimeService runtimeService =
				processEngine.getRuntimeService();
		RepositoryService repositoryService =
				processEngine.getRepositoryService();
		repositoryService.createDeployment()
		//.addInputStream("MyProcess.bpmn20.xml", new FileInputStream(absolutePath))
		.addClasspathResource("diagrams/MyProcess.bpmn")
		.deploy();
		ProcessInstance processInstance =
				runtimeService.startProcessInstanceByKey(
						"simplebookorder");
		assertNotNull(processInstance.getId());
		System.out.println("id " + processInstance.getId() + " " +
				processInstance.getProcessDefinitionId());
	}
}