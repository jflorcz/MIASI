import org.activiti.engine.TaskService;
import org.activiti.engine.delegate.DelegateTask;
import org.activiti.engine.delegate.TaskListener;
import org.springframework.beans.factory.annotation.Autowired;


public class ProcessTaskListener implements TaskListener {
	
	@Override
	public void notify(DelegateTask delegateTask) {
		// TODO Auto-generated method stub
		System.out.println("Task id " + delegateTask.getId());
		TaskService taskService = delegateTask.getExecution().getEngineServices().getTaskService();
		taskService.complete(delegateTask.getId());
	}

}
