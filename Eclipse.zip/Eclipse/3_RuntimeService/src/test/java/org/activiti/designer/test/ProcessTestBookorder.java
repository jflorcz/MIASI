package org.activiti.designer.test;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.activiti.engine.ProcessEngine;
import org.activiti.engine.ProcessEngineConfiguration;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.test.ActivitiRule;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;

public class ProcessTestBookorder {

	private static RuntimeService runtimeService;
	private static String filename = "./src/main/resources/diagrams/MyProcess.bpmn";
	
	
	@BeforeClass
	public static void init() throws FileNotFoundException {
		File fi = new File(filename);
		String absolutePath = fi.getAbsolutePath();
		
		ProcessEngine processEngine =
				ProcessEngineConfiguration
				.createStandaloneInMemProcessEngineConfiguration()
				.buildProcessEngine();
		RepositoryService repositoryService =
				processEngine.getRepositoryService();
		repositoryService.createDeployment()
		.addInputStream("MyProcess.bpmn20.xml", new FileInputStream(absolutePath))
				.deploy();
		runtimeService = processEngine.getRuntimeService();
	}
	
	@Test
	public void startProcessInstance() {
		Map<String, Object> variableMap =
				new HashMap<String, Object>();
		variableMap.put("isbn", "123456");
		ProcessInstance processInstance =
				runtimeService.startProcessInstanceByKey(
						"bookorder", variableMap);
		assertNotNull(processInstance.getId());
		System.out.println("id " + processInstance.getId() + " "
				+ processInstance.getProcessDefinitionId());
	}
	
	@Test
	public void queryProcessInstance() {
		List<ProcessInstance> instanceList = runtimeService
				.createProcessInstanceQuery()
				.processDefinitionKey("bookorder")
				.list();
		for (ProcessInstance queryProcessInstance : instanceList) {
			assertEquals(false, queryProcessInstance.isEnded());
			System.out.println("id " + queryProcessInstance.getId() +
					", ended=" + queryProcessInstance.isEnded());
		}
	}
}