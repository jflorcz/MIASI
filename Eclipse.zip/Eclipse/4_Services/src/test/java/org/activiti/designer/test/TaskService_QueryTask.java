package org.activiti.designer.test;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.Map;
import java.io.FileInputStream;

import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.activiti.engine.test.ActivitiRule;
import org.activiti.engine.test.Deployment;
import org.junit.Rule;
import org.junit.Test;

public class TaskService_QueryTask {

	@Rule
	public ActivitiRule activitiRule = new ActivitiRule();

	private void startProcessInstance() {
		RuntimeService runtimeService =
				activitiRule.getRuntimeService();
		Map<String, Object> variableMap =
				new HashMap<String, Object>();
		variableMap.put("isbn", "123456");
		runtimeService.startProcessInstanceByKey(
				"bookorder", variableMap);
	}
	
	@Test
	@Deployment(resources={"diagrams/MyProcess.bpmn"})
	public void queryTask() {
		startProcessInstance();
		TaskService taskService = activitiRule.getTaskService();
		
		Task task = taskService.createTaskQuery()
				.taskCandidateOrAssigned("kermit")
				.singleResult();
		
		assertEquals("Work on order", task.getName());
		System.out.println("task id " + task.getId() +
				", name " + task.getName() +
				", def key " + task.getTaskDefinitionKey());
	}
}